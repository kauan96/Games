var gulp = require('gulp');
var sass = require('gulp-sass');
var rename = require("gulp-rename");
var stripCssComments = require('gulp-strip-css-comments');

gulp.task('sass', function () {
gulp.src(['./assets/css/sections/*.scss'])
.pipe(stripCssComments())
.pipe(sass({
    errLogToConsole: true
}))
.pipe(rename("main.css"))
.pipe(gulp.dest('./assets/css/'));
});
