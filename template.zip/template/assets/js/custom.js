$(document).ready(function(){
	$(".toggle-button").click(function() {
		if($(".toggle-button").hasClass('toggle')){
			$(".toggle-button").removeClass('toggle');
			$(".menu").removeClass('active');
		} else {
			$(".toggle-button").addClass('toggle');
			$(".menu").addClass('active');
		}
	});
});